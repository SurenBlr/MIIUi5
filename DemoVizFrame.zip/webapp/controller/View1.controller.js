sap.ui.define([
	"sap/ui/core/mvc/Controller"
], function(Controller) {
	"use strict";

	return Controller.extend("DemoVizFrameDemoVizFrame.controller.View1", {
		onInit: function() {
			var oVizFrame = this.getView().byId("idcolumn");
			var oVizFrame2 = this.getView().byId("idpiechart");
			var oDataset = new sap.viz.ui5.data.FlattenedDataset({
				dimensions: [{
					axis: 1,
					name: "Cars",
					value: "{Model>Brand}"
				}],
				measures: [{
					name: "Sales",
					value: "{Model>Value}"
				}],
				data: {
					path: "Model>/Cars"
				}
			});
		
		
			oVizFrame.setDataset(oDataset);
			oVizFrame.setVizType('bar');
			
			oVizFrame2.setDataset(oDataset);
			oVizFrame2.setVizType('line');

			oVizFrame.setVizProperties({
				plotArea: {
					colorPalette: d3.scale.category20().range()
				},
				title: {
					visible: "true",
					text: "Vizframe Chart"
				}
			});
			var feedValueAxis = new sap.viz.ui5.controls.common.feeds.FeedItem({
					'uid': "valueAxis",
					'type': "Measure",
					'values': ["Sales"]
				}),
				feedCategoryAxis = new sap.viz.ui5.controls.common.feeds.FeedItem({
					'uid': "categoryAxis",
					'type': "Dimension",
					'values': ["Cars"]
				});
				
			oVizFrame.addFeed(feedValueAxis);
			oVizFrame.addFeed(feedCategoryAxis);
			oVizFrame2.addFeed(feedValueAxis);
			oVizFrame2.addFeed(feedCategoryAxis);
			
		}
	});
});